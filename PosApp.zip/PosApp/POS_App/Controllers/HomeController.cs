﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using POS_App.Models;

namespace POS_App.Controllers
{
    public class HomeController : Controller
    {
        DbOperations operation = new DbOperations();
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult ListAll()
        {
            return Json(operation.AllProducts(), JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        //public JsonResult AddProd(ProductsModel model)
        //{
        //    return Json(operation.AddProduct(model), JsonRequestBehavior.AllowGet);
        //}

        [HttpPost]
        public JsonResult AddProd(ProductsModel model)
        {
            // Call the AddProduct method to get the result list
            var result = operation.AddProduct(model);

            // Return the result as JSON
            return Json(result, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public JsonResult getbyID(int ID)
        {
            var Employee = operation.AllProducts().Find(x => x.ProductId.Equals(ID));
            return Json(Employee, JsonRequestBehavior.AllowGet);
        }

        

        [HttpPost]
        public JsonResult UpdateProd(ProductsModel model)
        {
            return Json(operation.UpdateProduct(model), JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteProd(int id)
        {
            int result = operation.DeleteProduct(id);
            if (result == 1)
            {

                return Json(new { status = 1, message = "Product deleted successfully!" }, JsonRequestBehavior.AllowGet);
            }
            else if(result==0)
            {
                return Json(new { status = 0, message = "Unable to delete. This product is already used in a sale." }, JsonRequestBehavior.AllowGet);
            }
            else
            { 
                return Json(new { status = -1, message = "An error occurred while trying to delete the product." }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult SalesPersonScreen()
        {
            return View();
        }

        [HttpGet]
        public JsonResult ListAllSalesPersons()
        {
            return Json(operation.AllSalesPerson(), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult AddSalesPer(SalespersonModel model)
        {
            int fetched_salespersonid = operation.AddSalesPerson(model);
            return Json( new { SalespersonID = fetched_salespersonid }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult getSalesPersonbyID(int ID)
        {
            var SalesPer = operation.AllSalesPerson().Find(x => x.SalespersonID.Equals(ID));
            return Json(SalesPer, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult UpdateSalesPer(SalespersonModel model)
        {
            return Json(operation.UpdateSalesPerson(model), JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteSalesPer(int id)
        {
            return Json(operation.DeleteSalesPerson(id), JsonRequestBehavior.AllowGet);
        }

        //POS related functions
        public ActionResult Point_Of_Sale()
        {
            return View();
        }

        [HttpGet]
        public JsonResult ProdDetail(string name)
        {
            return Json(operation.Product_Detail(name),JsonRequestBehavior.AllowGet);
        }

       


        [HttpGet]
        public JsonResult GetProductID(string name)
        {
            return Json(operation.GetProductIdByName(name), JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SaveData(SalesMasterModel SMM, List<SalesDetailModel> salesDetails)
        {
            
            if (salesDetails == null || salesDetails.Count == 0)
            {
                return Json(new { success = false, message = "Sales details cannot be empty." });
            }

            try
            {
                int result = operation.SaveSalesData(SMM, salesDetails);
                return Json(new { success = true, result });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Error saving data: " + ex.Message });
            }
        }




        //RecordsTab functions
        public ActionResult RecordsTab()
        {
            return View();
        }

        [HttpGet]
        public JsonResult Load_Records()
        {
            return Json(operation.LoadRecords(), JsonRequestBehavior.AllowGet);
        }

        

        //[HttpPost]
        //public JsonResult Fill_The_Relevant_Data(int saleid)
        //{

        //    return Json(operation.FillTheRelevantData(saleid), JsonRequestBehavior.AllowGet);
        //}

        [HttpPost]
        public JsonResult Fill_The_Relevant_Data(int saleid)
        {
            var data = operation.FillTheRelevantData(saleid);

            foreach (var item in data)
            {
                if (item.SalespersonID == null)
                {
                    item.SalespersonID = null;  
                }
            }

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GivePOSViewForEditing()
        {
            return View("Point_Of_Sale");
        }

        [HttpPost]
        public JsonResult Delete_Sale(int saleid)
        {
            return Json(operation.DeleteSaleBySaleId(saleid),JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Update_Data(SalesMasterModel SMM, List<SalesDetailModel> salesDetails)
        {
            if (salesDetails == null || salesDetails.Count == 0)
            {
                return Json(new { success = false, message = "Sales details cannot be empty." });
            }

            try
            {
                bool result = operation.UpdateSaleData(SMM, salesDetails);
                return Json(new { success = true, result });
            }
            catch (Exception ex)
            {
                return Json(operation.UpdateSaleData(SMM, salesDetails), JsonRequestBehavior.AllowGet);
            }
            
        }

        [HttpPost]
        public JsonResult Delete_Sale_During_Editing(int saleid)
        {
            return Json(operation.DeleteSaleBySaleId(saleid), JsonRequestBehavior.AllowGet);
        }

       

    }
}