﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POS_App.Models
{
    public class SalesMasterModel
    {
        public int SaleId { get; set; }
        public decimal Total { get; set; }

        public DateTime SaleDate { get; set; }

        public SalespersonModel SalespersonID { get; set; }

        public string Comments { get; set; }

               
    }
}