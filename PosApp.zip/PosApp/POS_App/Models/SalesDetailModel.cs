﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POS_App.Models
{
    public class SalesDetailModel
    {
            public int SaleDetailId { get; set; }    // Primary key
            public SalesMasterModel SaleId { get; set; }           // Foreign key to SalesMaster
            public ProductsModel ProductId { get; set; }        // Foreign key to Products
            public decimal RetailPrice { get; set; }  // Retail price of the product
            public int Quantity { get; set; }         // Quantity sold
            public decimal Discount { get; set; }     // Discount applied
            
            

    }
}