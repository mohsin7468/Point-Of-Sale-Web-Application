﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POS_App.Models
{
    public class ProductsModel
    {
        public int ProductId { get; set; }

        public string Name { get; set; }

        public string Code { get; set; }

        public string ImageURL { get; set; }

        public decimal CostPrice { get; set; }

        public decimal RetailPrice { get; set; }

        public DateTime CreationDate { get; set; }
    }
}