﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POS_App.Models
{
    public class SaleDetailSummaryModel
    {
        public int SaleId { get; set; }
        public string ProductName { get; set; }  // Product name from the Products table
        public string ProductCode { get; set; }  // Product code from the Products table
        public int Quantity { get; set; }        // Quantity sold from SalesDetail table
        public decimal Discount { get; set; }    // Discount applied to the product in SalesDetail
        public decimal RetailPrice { get; set; } // Retail price from the Products table
        public decimal Total { get; set; }       // Total sale amount from SalesMaster table
        
        public DateTime SaleDate { get; set; }
        public Nullable<int> SalespersonID { get; set; }

        public string Comments { get; set; }
    }
}