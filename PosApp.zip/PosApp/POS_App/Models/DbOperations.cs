﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace POS_App.Models
{

    public class DbOperations
    {
        string cs = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

        //List of all Products
        public List<ProductsModel> AllProducts()
        {
            List<ProductsModel> prod = new List<ProductsModel>();
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("SelectProduct", con);
                com.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = com.ExecuteReader();
                while (rdr.Read())
                {
                    prod.Add(new ProductsModel
                    {
                        ProductId = Convert.ToInt32(rdr["ProductId"]),
                        Name = rdr["Name"].ToString(),
                        Code = rdr["Code"].ToString(),
                        ImageURL = rdr["ImageURL"].ToString(),
                        CostPrice = Convert.ToDecimal(rdr["CostPrice"]),
                        RetailPrice = Convert.ToDecimal(rdr["RetailPrice"]),
                        CreationDate = Convert.ToDateTime(rdr["CreationDate"])

                    });
                }
                return prod;

            }

        }

        //public int AddProduct(ProductsModel model)
        //{
        //    int productId = 0;
        //    DateTime creationDate = DateTime.MinValue; // Set a default value for creationDate

        //    using (SqlConnection con = new SqlConnection(cs))
        //    {
        //        con.Open();
        //        SqlCommand com = new SqlCommand("InsertProduct", con);
        //        com.CommandType = CommandType.StoredProcedure;
        //        com.Parameters.AddWithValue("@Name", model.Name);
        //        com.Parameters.AddWithValue("@Code", model.Code);
        //        com.Parameters.AddWithValue("@ImageURL", (object)model.ImageURL ?? DBNull.Value);
        //        //com.Parameters.AddWithValue("@ImageURL", model.ImageURL);
        //        com.Parameters.AddWithValue("@CostPrice", model.CostPrice);
        //        com.Parameters.AddWithValue("@RetailPrice", model.RetailPrice);
        //        // Execute the query and retrieve the returned values (ProductId and CreationDate)
        //        using (SqlDataReader reader = com.ExecuteReader())
        //        {
        //            if (reader.Read())
        //            {
        //                productId = reader.GetInt32(reader.GetOrdinal("ProductId"));
        //                creationDate = reader.GetDateTime(reader.GetOrdinal("CreationDate"));
        //            }
        //        }
        //    }
        //    return (productId, creationDate);
        //}

        public List<ProductResult> AddProduct(ProductsModel model)
        {
            var productResults = new List<ProductResult>();

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("InsertProduct", con);
                com.CommandType = CommandType.StoredProcedure;

                // Add input parameters
                com.Parameters.AddWithValue("@Name", model.Name);
                com.Parameters.AddWithValue("@Code", model.Code);
                com.Parameters.AddWithValue("@ImageURL", (object)model.ImageURL ?? DBNull.Value);
                com.Parameters.AddWithValue("@CostPrice", model.CostPrice);
                com.Parameters.AddWithValue("@RetailPrice", model.RetailPrice);

                // Execute the stored procedure and retrieve the result
                using (SqlDataReader reader = com.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Read ProductId and CreationDate and add to the list
                        var productResult = new ProductResult
                        {
                            ProductId = reader.GetInt32(reader.GetOrdinal("ProductId")),
                            CreationDate = reader.GetDateTime(reader.GetOrdinal("CreationDate"))
                        };

                        // Add the result to the list
                        productResults.Add(productResult);
                    }
                }
            }

            return productResults;
        }



        public int UpdateProduct(ProductsModel model)
        {
            int i = 0;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("UpdateProduct", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@ProductId", model.ProductId);
                com.Parameters.AddWithValue("@Name", model.Name);
                com.Parameters.AddWithValue("@Code", model.Code);
                com.Parameters.AddWithValue("@ImageURL", model.ImageURL);
                com.Parameters.AddWithValue("@CostPrice", model.CostPrice);
                com.Parameters.AddWithValue("@RetailPrice", model.RetailPrice);
                i = com.ExecuteNonQuery();
            }
            return i;

        }


        public int DeleteProduct(int ID)
        {
            int i = 0;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("DeleteProduct", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@ProductId", ID);

                i = (int)com.ExecuteScalar();
            }
            return i;
        }

        //Salesperson Data Base Operations
        public List<SalespersonModel> AllSalesPerson()
        {
            List<SalespersonModel> salesP = new List<SalespersonModel>();
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("SelectSalesPerson", con);
                com.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = com.ExecuteReader();
                while (rdr.Read())
                {
                    salesP.Add(new SalespersonModel
                    {
                        SalespersonID = Convert.ToInt32(rdr["SalespersonID"]),
                        Name = rdr["Name"].ToString(),
                        Code = rdr["Code"].ToString(),
                        EnteredDate = Convert.ToDateTime(rdr["EnteredDate"])

                    });
                }
                return salesP;

            }

        }

        //public int AddSalesPerson(SalespersonModel model)
        //{
        //    int i = 0;
        //    using (SqlConnection con = new SqlConnection(cs))
        //    {
        //        con.Open();
        //        SqlCommand com = new SqlCommand("InsertSalesPerson", con);
        //        com.CommandType = CommandType.StoredProcedure;
        //        com.Parameters.AddWithValue("@Name", model.Name);
        //        com.Parameters.AddWithValue("@Code", model.Code);
        //        i = com.ExecuteNonQuery();
        //    }
        //    return i;
        //}

        public int AddSalesPerson(SalespersonModel model)
        {
            int salespersonId = 0; // This will store the newly generated SalespersonID

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();

                SqlCommand com = new SqlCommand("InsertSalesPerson", con);
                com.CommandType = CommandType.StoredProcedure;

                // Add input parameters
                com.Parameters.AddWithValue("@Name", model.Name);
                com.Parameters.AddWithValue("@Code", model.Code);

                // Add output parameter for the SalespersonID
                SqlParameter outputParam = new SqlParameter("@SalespersonID", SqlDbType.Int);
                outputParam.Direction = ParameterDirection.Output;
                com.Parameters.Add(outputParam);

                // Execute the stored procedure
                com.ExecuteNonQuery();

                // Retrieve the value of the output parameter (the newly inserted SalespersonID)
                salespersonId = (int)outputParam.Value;
            }

            return salespersonId; // Return the newly inserted SalespersonID
        }


        public int UpdateSalesPerson(SalespersonModel model)
        {
            int i = 0;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("UpdateSalesPerson", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@SalespersonID", model.SalespersonID);
                com.Parameters.AddWithValue("@Name", model.Name);
                com.Parameters.AddWithValue("@Code", model.Code);
                i = com.ExecuteNonQuery();
            }
            return i;

        }


        public int DeleteSalesPerson(int ID)
        {
            int i = 0;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("DeleteSalesPerson", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@SalespersonID", ID);

                i = com.ExecuteNonQuery();
            }
            return i;
        }

        //Point Of Sale Screen Methods

        public ProductsModel Product_Detail(string ProductName)
        {
            ProductsModel singleProd = new ProductsModel();
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("SelectProduct", con);
                com.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = com.ExecuteReader();
                while (rdr.Read())
                {
                    string TestName = rdr["Name"].ToString();
                    if (TestName == ProductName)
                    {

                        singleProd.ProductId = Convert.ToInt32(rdr["ProductId"]);
                        singleProd.Name = rdr["Name"].ToString();
                        singleProd.Code = rdr["Code"].ToString();
                        singleProd.RetailPrice = Convert.ToDecimal(rdr["RetailPrice"]); //price


                    }
                }
                return singleProd;
            }
        }


        public int GetProductIdByName(string productName)
        {

            if (string.IsNullOrWhiteSpace(productName))
            {
                throw new ArgumentException("Product name cannot be null or empty.", nameof(productName));
            }

            int productId = 0;


            using (var connection = new SqlConnection(cs))
            {
                connection.Open();
                var command = new SqlCommand("SELECT ProductId FROM Products WHERE Name = @Name", connection);
                command.Parameters.AddWithValue("@Name", productName);

                var result = command.ExecuteScalar();


                if (result != null)
                {
                    productId = Convert.ToInt32(result);
                }
            }

            return productId;
        }

        public int SaveSalesData(SalesMasterModel salesMaster, List<SalesDetailModel> salesDetails)
        {
            if (salesMaster == null) throw new ArgumentNullException(nameof(salesMaster));
            if (salesDetails == null || salesDetails.Count == 0) throw new ArgumentException("Sales details cannot be null or empty.", nameof(salesDetails));

            int saleId = 0;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand command = new SqlCommand("sp_InsertSalesMaster", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Total", salesMaster.Total);
                //command.Parameters.AddWithValue("@SalespersonId", salesMaster.SalespersonID.SalespersonID);
                command.Parameters.AddWithValue("@SalespersonId",
                salesMaster.SalespersonID?.SalespersonID ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@SaleDate", salesMaster.SaleDate);
                command.Parameters.AddWithValue("@Comments", salesMaster.Comments ?? (object)DBNull.Value);
                saleId = Convert.ToInt32(command.ExecuteScalar());
                SqlCommand com = new SqlCommand("sp_InsertSalesDetail", con);

                foreach (var detail in salesDetails)
                {
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.Clear();
                    com.Parameters.AddWithValue("@SaleId", saleId);
                    com.Parameters.AddWithValue("@ProductId", detail.ProductId.ProductId);
                    com.Parameters.AddWithValue("@RetailPrice", detail.RetailPrice);
                    com.Parameters.AddWithValue("@Quantity", detail.Quantity);
                    com.Parameters.AddWithValue("@Discount", detail.Discount);
                    com.ExecuteNonQuery();
                }

            }

            return saleId;
        }



        //Records Screen Related functions
        public int GetSalesPersonById(int id)
        {
            id = 0;
            using (SqlConnection peter = new SqlConnection(cs))
            {
                peter.Open();
                SqlCommand commandant = new SqlCommand("SELECT SalespersonID FROM Salesperson WHERE SalespersonID = @SalespersonID;", peter);
                commandant.Parameters.AddWithValue("@SalespersonID", id);
                commandant.ExecuteScalar();
            }
            return id;
        }



        public List<SalesMasterModel> LoadRecords()
        {
            List<SalesMasterModel> recordlist = new List<SalesMasterModel>();

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("GetSalesInfo", con);
                com.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = com.ExecuteReader();
                while (rdr.Read())
                {
                    SalesMasterModel salesMaster = new SalesMasterModel
                    {
                        SaleDate = Convert.ToDateTime(rdr["SaleDate"]),
                        Total = Convert.ToDecimal(rdr["Total"]),
                        SalespersonID = new SalespersonModel
                        {

                            Name = rdr["SalespersonName"].ToString()
                        },
                        SaleId = Convert.ToInt32(rdr["SaleId"]),
                        Comments = rdr["Comments"].ToString()

                    };
                    recordlist.Add(salesMaster);

                }
            }

            return recordlist;
        }


        public List<SaleDetailSummaryModel> FillTheRelevantData(int saleid)
        {
            List<SaleDetailSummaryModel> list = new List<SaleDetailSummaryModel>();
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("GetSaleDetailsBySaleId", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@SaleId", saleid);

                SqlDataReader rdr = com.ExecuteReader();
                while (rdr.Read())
                {
                    SaleDetailSummaryModel model = new SaleDetailSummaryModel
                    {
                        SaleId = Convert.ToInt32(rdr["SaleId"]),
                        ProductName = rdr["ProductName"].ToString(),
                        ProductCode = rdr["ProductCode"].ToString(),
                        Quantity = Convert.ToInt32(rdr["Quantity"]),
                        Discount = Convert.ToDecimal(rdr["Discount"]),
                        RetailPrice = Convert.ToDecimal(rdr["RetailPrice"]),
                        Total = Convert.ToDecimal(rdr["Total"]),
                        SaleDate = Convert.ToDateTime(rdr["SaleDate"]),
                        SalespersonID = rdr["SalespersonID"] == DBNull.Value ? (int?)null : Convert.ToInt32(rdr["SalespersonID"]),
                        Comments = rdr["Comments"].ToString()
                    };

                    list.Add(model);
                }

            }
            return list;

        }
        public int DeleteSaleBySaleId(int val)
        {
            int i = 0;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("DeleteSalesDatabyID", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@SaleId", val);
                i = com.ExecuteNonQuery();
            }
            return i;
        }

        public bool UpdateSaleData(SalesMasterModel SMM, List<SalesDetailModel> salesDetails)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();

                    using (SqlCommand cmd = new SqlCommand("UPDATE SalesMaster SET SaleDate = @SaleDate, SalespersonId = @SalespersonId, Comments = @Comments, Total = COALESCE(@Total, Total) WHERE SaleId = @SaleId;", con))
                    {
                        cmd.Parameters.AddWithValue("@SaleDate", SMM.SaleDate);
                        //cmd.Parameters.AddWithValue("@SalespersonId", SMM.SalespersonID.SalespersonID);
                        if (SMM.SalespersonID != null && SMM.SalespersonID.SalespersonID.HasValue)
                        {
                            cmd.Parameters.Add("@SalespersonId", SqlDbType.Int).Value = SMM.SalespersonID.SalespersonID.Value;
                        }
                        else
                        {
                            cmd.Parameters.Add("@SalespersonId", SqlDbType.Int).Value = DBNull.Value;
                        }

                        cmd.Parameters.AddWithValue("@Comments", SMM.Comments ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@Total", SMM.Total);
                        cmd.Parameters.AddWithValue("@SaleId", SMM.SaleId);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            Console.WriteLine("No record found with the provided SaleId.");
                            return false; 
                        }
                    }

                  
                    List<int> existingProductIds = new List<int>();
                    using (SqlCommand cmdGetExistingProducts = new SqlCommand("SELECT ProductId FROM SalesDetail WHERE SaleId = @SaleId;", con))
                    {
                        cmdGetExistingProducts.Parameters.AddWithValue("@SaleId", SMM.SaleId);

                        using (SqlDataReader reader = cmdGetExistingProducts.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                existingProductIds.Add(reader.GetInt32(0));
                            }
                        }
                    }

                    // Delete the products in SalesDetail that are no longer in the update request
                    foreach (var productId in existingProductIds)
                    {
                        if (!salesDetails.Any(sd => sd.ProductId.ProductId == productId))
                        {
                            // Product is no longer part of the sale, so delete it from SalesDetail
                            using (SqlCommand cmdDelete = new SqlCommand("DELETE FROM SalesDetail WHERE SaleId = @SaleId AND ProductId = @ProductId;", con))
                            {
                                cmdDelete.Parameters.AddWithValue("@SaleId", SMM.SaleId);
                                cmdDelete.Parameters.AddWithValue("@ProductId", productId);
                                cmdDelete.ExecuteNonQuery();
                            }
                        }
                    }

                    foreach (var detail in salesDetails)
                    {
                       
                        using (SqlCommand cmdCheck = new SqlCommand("SELECT COUNT(*) FROM SalesDetail WHERE SaleId = @SaleId AND ProductId = @ProductId;", con))
                        {
                            cmdCheck.Parameters.AddWithValue("@SaleId", SMM.SaleId);
                            cmdCheck.Parameters.AddWithValue("@ProductId", detail.ProductId.ProductId);

                            int existingRecordCount = (int)cmdCheck.ExecuteScalar();

                            if (existingRecordCount > 0)
                            {
                               
                                using (SqlCommand cmdUpdate = new SqlCommand("UPDATE SalesDetail SET RetailPrice = @RetailPrice, Quantity = @Quantity, Discount = @Discount WHERE SaleId = @SaleId AND ProductId = @ProductId;", con))
                                {
                                    cmdUpdate.Parameters.AddWithValue("@RetailPrice", detail.RetailPrice);
                                    cmdUpdate.Parameters.AddWithValue("@Quantity", detail.Quantity);
                                    cmdUpdate.Parameters.AddWithValue("@Discount", detail.Discount);
                                    cmdUpdate.Parameters.AddWithValue("@SaleId", SMM.SaleId);
                                    cmdUpdate.Parameters.AddWithValue("@ProductId", detail.ProductId.ProductId);
                                    cmdUpdate.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                
                                using (SqlCommand cmdInsert = new SqlCommand("INSERT INTO SalesDetail (SaleId, ProductId, RetailPrice, Quantity, Discount) VALUES (@SaleId, @ProductId, @RetailPrice, @Quantity, @Discount);", con))
                                {
                                    cmdInsert.Parameters.AddWithValue("@SaleId", SMM.SaleId);
                                    cmdInsert.Parameters.AddWithValue("@ProductId", detail.ProductId.ProductId);
                                    cmdInsert.Parameters.AddWithValue("@RetailPrice", detail.RetailPrice);
                                    cmdInsert.Parameters.AddWithValue("@Quantity", detail.Quantity);
                                    cmdInsert.Parameters.AddWithValue("@Discount", detail.Discount);
                                    cmdInsert.ExecuteNonQuery();
                                }
                            }
                        }
                    }

                    return true; 
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return false; 
                }
            }
        }






    }
}
    

            

           
        




    




