﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POS_App.Models
{
    public class SalespersonModel
    {
        public int? SalespersonID { get; set; }

        public string Name { get; set; }
        public string Code { get; set; }

        public DateTime EnteredDate { get; set; }
    }
}