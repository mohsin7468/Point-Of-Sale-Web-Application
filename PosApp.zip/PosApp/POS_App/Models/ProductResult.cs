﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POS_App.Models
{
    public class ProductResult
    {
        public int ProductId { get; set; }
        public DateTime CreationDate { get; set; }
    }

}