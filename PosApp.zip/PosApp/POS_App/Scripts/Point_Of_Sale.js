﻿var Global_Sale_Id = 0;

$(document).ready(function () {
    ///////////////////////////////////////////////////
    
    
    $('.records').hide();
    $('#sales-tab').on('click', function () {
        // Show the 'sale' div and hide the 'records' div
        $('#sale').show();
        $('.records').hide();
    });

    $('#records-tab').on('click', function () {
        
        $('.records').show();
        $('#sale').hide();
        
        
    });
    $(document).on('click', 'button, a', function (event) {
        if ($(this).hasClass('12')) {
            return; // Do nothing, allow normal action link behavior
        }
        event.preventDefault(); // Prevents the default action (scrolling)
        event.stopPropagation(); // Prevents event bubbling
    });
   

    ///////////////////////////////////////////////////
    startClock();   
    LoadDataInSalesPersonDropDown();
    Search_Funtionality();
    var table = $('#myTable').DataTable({
        "ordering": false,  // Disables sorting functionality on all columns
        "language": {
            "emptyTable": "",  // Set the empty table message to be an empty string
            "zeroRecords": "",  // Hide the "No matching records found" message
            "info": ""
        },
        "drawCallback": function (settings) {
            // Hide the info message when the table is empty
            var api = this.api();
            if (api.rows().count() === 0) {
                // Manually hide the "info" element
                $(api.table().container()).find('.dataTables_info').hide();
            } else {
                // Show the "info" element if rows exist
                $(api.table().container()).find('.dataTables_info').show();
            }
        }
    });
    //var table_instance = $('#myTable').DataTable();
    var saleDetails = localStorage.getItem('saleDetails');
    
    if (saleDetails) {
        stopClock();
        saleDetails = JSON.parse(saleDetails);
        var S_id = 0;

        saleDetails.forEach(function (sale) {              
           S_id = sale.SaleId;
        });

        console.log('logan paul ',S_id);
        Global_Sale_Id = S_id;

        var refilledSaleDate;
        var refilledSalesPersonDropDown;
        var formattedDate;
        let fetched_sales_person_id;
        var fetched_comment;
        var totalRowAmount = 0;
        var grandTotal = 0;
        $('#messageDiv').text('Editing MODE Activated');
        
        // Use `table.clear()` to clear the existing rows if necessary
        table.clear();

        // Loop through saleDetails and add rows to the DataTable
        $.each(saleDetails, function (index, item) {
            totalRowAmount = (item.Quantity * item.RetailPrice) - (item.Quantity * item.RetailPrice * (item.Discount / 100));

            // Add row to DataTable dynamically
            table.row.add([
                item.ProductName,
                item.ProductCode,
                '<input id="quantityfield" type="number" min="1" value="' + item.Quantity + '" class="quantity-input" onchange="updateTotal(this)" />',
                '<input id="discountfield" type="number" min="0" max="100" step="0.01" value="' + item.Discount + '" class="discount-input" onchange="updateTotal(this)"/>',
                item.RetailPrice.toFixed(2),
                '<input type="text" value="' + totalRowAmount.toFixed(2) + '" disabled class="total-amount" />',
                '<a href="#" class="btn btn-outline-danger" onclick="Delete(this)">Delete</a>'
            ]).draw(false);

            formattedDate = formatMicrosoftJsonDateForInput(item.SaleDate);
            fetched_sales_person_id = item.SalespersonID;
            fetched_comment = item.Comments;
            grandTotal = item.Total;
        });

        // Update the fields for editing
        $('#dateTimeInput').val(formattedDate);
        SelectValueInSalesPersonDropDown(fetched_sales_person_id);
        $('#floatingTextarea').val(fetched_comment);
        $('#myTable').on('focus', '#quantityfield, #discountfield', function () {
            this.select();
        });

        // Add Grand Total row (or update if already present)
        if ($('#myTable tbody .grand-total-row').length === 0) {
            $('#myTable tbody').append('<tr class="grand-total-row"><td></td><td></td><td></td><td></td><td></td><td><strong>Grand Total: </strong><span id="grandTotal">' + grandTotal.toFixed(2) + '</span></td><td></td></tr>');
        } else {
            $('#myTable tbody .grand-total-row #grandTotal').text(grandTotal.toFixed(2));
        }

        
        localStorage.removeItem('saleDetails');
        $('#saveButton').hide();
        $('#clearButton').hide();
        $('#updateButton').show();
        $('#deleteButton').show();
        $('#newsaleButton').show();

    }
    else
    {
        console.log('No sale details found in localStorage');
    }

});

function formatMicrosoftJsonDateForInput(jsonDate) {
    const match = jsonDate.match(/\/Date\((\d+)\)\//);
    if (!match) {
        console.error("Invalid Microsoft JSON Date format");
    }
    const timestamp = parseInt(match[1], 10);
    const date = new Date(timestamp);
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');
    const result = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
    return result;
}



function Load_Row_In_Table(productName) {
    stopClock();
    
    if (productName == '') {
        alert('Product Name Cannot be Empty');
        return;
    }
    $.ajax({
        url: "/Home/ProdDetail?name=" + productName,
        type: "get",
        dataType: "json",
        success: function (result) {
            console.log(result);
            if (productName === result.Name) {
                if ($('.dataTables_empty').is(':visible')) {
                    $('.dataTables_empty').hide();
                }
                //var table = $('#myTable').DataTable({
                //"ordering": false  // Disables sorting functionality on all columns
                //});
                

                var exists = false;
                var existingRow;

                table.rows().every(function () {
                    var data = this.data();
                    if (data[0].toLowerCase() === result.Name.toLowerCase()) {
                        exists = true;
                        existingRow = this;
                    }
                });

                if (exists) {
                    var $row = $(existingRow.node());
                    var quantityInput = $row.find('.quantity-input');
                    var currentQuantity = parseInt(quantityInput.val(), 10);
                    currentQuantity += 1;
                    quantityInput.val(currentQuantity);
                    updateTotal(quantityInput);
                    //alert('Increased quantity of ' + result.Name + ' by 1.');
                    return;
                }

                // Add new row to the DataTable
                var newRow = table.row.add([
                    result.Name,
                    result.Code,
                    '<input type="number" min="1" value="1" class="quantity-input" onchange="updateTotal(this)" />',
                    '<input type="number" min="0" max="100" step="0.01" value="0" class="discount-input" onchange="updateTotal(this)" />',
                    result.RetailPrice,
                    '<input type="text" value="0" disabled class="total-amount" />',
                    '<a href="#" class="btn btn-outline-danger" onclick="Delete(this)">Delete</a>'
                ]).draw(false);


                // Calculate total amount for the new row
                var rowNode = newRow.node();
                updateTotal($(rowNode).find('.quantity-input')); // Update total for the new row

                $('#myTable').on('focus', '.quantity-input, .discount-input', function () {
                    this.select(); // Select the input value when focused
                });

                updateGrandTotalRow();

            } else {
                alert('No product found.');
            }
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

function updateTotal(input) {
    var $row = $(input).closest('tr');
    var quantity = parseInt($row.find('.quantity-input').val(), 10) || 0;
    var discount = parseFloat($row.find('.discount-input').val()) || 0;
    var pricePerUnit = parseFloat($row.find('td').eq(4).text()) || 0;

    if (quantity < 1) {
        quantity = 1;
        $row.find('.quantity-input').val(quantity);
    }

    var totalAmount = (quantity * pricePerUnit) - (quantity * pricePerUnit * (discount / 100));
    $row.find('.total-amount').val(totalAmount.toFixed(2));
    updateGrandTotalRow();

}

function calculateGrandTotal() {
    var grandTotal = 0;
    $('#myTable tbody tr').each(function () {
        var totalAmount = parseFloat($(this).find('.total-amount').val()) || 0;
        grandTotal += totalAmount;
    });
    return grandTotal;
}


function updateGrandTotalRow() {
    var grandTotal = calculateGrandTotal();
    var $grandTotalRow = $('#myTable tbody tr.grand-total-row');

    if ($grandTotalRow.length === 0) {
        
        $('#myTable tbody').append(`
            <tr class="grand-total-row">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><strong>Grand Total: </strong><span id="grandTotal">0.00</span></td>
                        <td></td>
            </tr>
        `);

    } else {
        
        $grandTotalRow.find('#grandTotal').text(grandTotal.toFixed(2));
    }
}

function Delete(row) {

    var table = $('#myTable').DataTable();
    table.row($(row).closest('tr')).remove().draw(false);
    //alert('Product Deleted!');
    var grandTotal = calculateGrandTotal();
    var $grandTotalRow = $('#myTable tbody tr.grand-total-row');
    if ($grandTotalRow.length > 0) {
        
        $grandTotalRow.find('#grandTotal').text(grandTotal.toFixed(2));
    } else {
        
        $('#myTable tbody').append(`
            <tr class="grand-total-row">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><strong>Grand Total: </strong><span id="grandTotal">0.00</span></td>
                        <td></td>
            </tr>
        `);
    }
    updateGrandTotalRow();
}


let intervalId;  

function getCurrentDateTime() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
}



function startClock() {
    intervalId = setInterval(function () {
        const currentTime = getCurrentDateTime();
        
        $('#dateTimeInput').val(currentTime);
    }, 1000); 
}


function stopClock() {
    clearInterval(intervalId); 
    console.log("Clock stopped.");
}




function LoadDataInSalesPersonDropDown() {
    $.ajax({
        url: "/Home/ListAllSalesPersons",
        type: "GET",
        dataType: "json",
        success: function (result) {
            console.log(result);
            var html = '';
            var html = '<option selected disabled>Choose Relevant Sales-Person</option>';
            $.each(result, function (key, item) {

                html += '<option value="' + item.SalespersonID + '">' + item.Name + '</option>';

            });
            $('.form-select').html(html);
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });

}




function SelectValueInSalesPersonDropDown(val) {
    $.ajax({
        url: "/Home/ListAllSalesPersons",
        type: "GET",
        dataType: "json",
        success: function (result) {
            console.log(result);

            var html = '<option selected disabled>Choose Relevant Sales-Person</option>'; 

            $.each(result, function (key, item) {
                html += '<option value="' + item.SalespersonID + '">' + item.Name + '</option>';
            });

            $('.form-select').html(html);

            $('#inputGroupSelect04').val(val);  
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

//modal funtionality code

function invokeModal() {
    const myModal = new bootstrap.Modal(document.getElementById('myModal'));
    myModal.show();

    const buttons = document.querySelectorAll('#myModal .modal-footer button');
    let currentIndex = 0;

    myModal._element.addEventListener('shown.bs.modal', () => {
        focusButton(currentIndex); 
    });


    function focusButton(index) {
        buttons[index].focus();
    }

    $(document).on('keydown', function (e) {
        if ($('#myModal').hasClass('show')) { 
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                
                currentIndex = (currentIndex + 1) % buttons.length;
                focusButton(currentIndex);
            } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                
                currentIndex = (currentIndex - 1 + buttons.length) % buttons.length;
                focusButton(currentIndex);
            } else if (e.key === 'Enter') {
                 e.preventDefault(); 
                e.stopPropagation(); 
                
                buttons[currentIndex].click();
            }
        }
    });
}



//2nd modal function
function invoke_Product_Addition_Model() {
    const myModal = new bootstrap.Modal(document.getElementById('ProductsModal'));
    myModal.show();
    ShowAllClickAbleProducts();
    const myInput = document.getElementById('myInput');
    myModal._element.addEventListener('shown.bs.modal', () => {
        if (myInput) {
            myInput.focus();
        }
    });
}



function getProductId(productName) {
    if (!productName) {
        alert('Product name cannot be empty');
        return null; 
    }

    var productId = null; 

    $.ajax({
        url: "/Home/GetProductID?name=" + encodeURIComponent(productName),
        type: "GET",
        contentType: "application/json",
        dataType: "json",
        async: false, 
        success: function (response) {
            productId = response; 
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });

    return productId;
}


function SaveData() {
    var grandTotal = $('#grandTotal').text();
    var salesPersonId = $('#inputGroupSelect04').val(); 
    //console.log('The ID is:', salesPersonId);
    var saleDate = $('#dateTimeInput').val(); 
    var comments = $('#floatingTextarea').val(); 

    var table = $('#myTable').DataTable();

    if (table.rows().count() === 0) {
        

        Swal.fire({
            title: 'Error!',
            text: 'No Sales Records present in table!',
            icon: 'error',
            showConfirmButton: true, // Show the default "OK" button
        }).then(() => {
            // You can do something when the SweetAlert is closed, if needed
        });

        // Add event listener for "Enter" key press
        $(document).on('keydown', function (e) {
            if (e.key === 'Enter' && Swal.isVisible()) {  // Check if SweetAlert is visible
                Swal.close();  // Close the SweetAlert when Enter is pressed
            }
        });

        return;
    }

    var tableData = [];
    table.rows().every(function () {
        var data = this.data();
        var productName = data[0];
        var productId = getProductId(productName);

        var quantityInput = $(this.node()).find('td:eq(2) input');
        var discountInput = $(this.node()).find('td:eq(3) input');

        var quantity = parseInt(quantityInput.val(), 10) || 0;
        var discount = parseFloat(discountInput.val()) || 0.0;

        if (productId !== null) {
            tableData.push({
                ProductId: { ProductId: productId },
                RetailPrice: parseFloat(data[4]),
                Quantity: quantity,
                Discount: discount
            });
        } else {
            alert('Could not retrieve Product ID for ' + productName);
            return;
        }
    });

    console.log(tableData); 
    console.log('I have sent this:', JSON.stringify({
        SalespersonID: { SalespersonID: salesPersonId },
        Total: grandTotal,
        SaleDate: saleDate,
        Comments: comments,
        SalesDetails: tableData
    }));

    $.ajax({
        url: "/Home/SaveData",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            // Pass SalespersonID as null or a valid ID
            //SalespersonID: salesPersonId || null,  // If salesPersonId is not set, send null
            SalespersonID: salesPersonId? { SalespersonID: salesPersonId } : null,
            Total: grandTotal,
            SaleDate: saleDate,
            Comments: comments,
            SalesDetails: tableData  
        }),
        dataType: "json",
        success: function (response) {
            if (response.success) {
                Swal.fire({
                    title: 'Success!', text: 'Sale Entered successfully.', icon: 'success'
                });
                $(document).on('keydown', function (e) {
                    if (e.key === 'Enter' && Swal.isVisible()) {  // Check if SweetAlert is visible
                        Swal.close();  // Close the SweetAlert when Enter is pressed
                    }
                });
                table.clear().draw();
                $('.dataTables_empty').hide();
                $('#productSearch').val('');
                $('#inputGroupSelect04').val('').change();
                $('#floatingTextarea').val('');
                $('#myModal').modal('hide');
                startClock();
                populate_Records_table_again();

            } else {
                alert('Failed to save data: ' + response.message);  
            }
        },
        error: function (errormessage) {
            console.error('Error:', errormessage);
            alert('An error occurred: ' + errormessage.responseText);
        }
    });

}



function ShowAllClickAbleProducts() {
    var table = $('#TunaTable').DataTable();
    table.destroy();
    

    $.ajax({
        url: "/Home/ListAll",
        type: "GET",
        dataType: "json",
        success: function (result) {
            console.log("fetched products: ", result);

            var html = '';
            $.each(result, function (key, item) {
                html += '<tr data-code="' + item.Code + '" data-name="' + item.Name + '" data-price="' + item.RetailPrice + '" data-image="' + item.ImageURL + '">';
                html += '<td>' + item.Code + '</td>';
                html += '<td>' + item.Name + '</td>';
                html += '<td><img style="max-width:100px;" src="' + item.ImageURL + '" alt="Product Image"></td>';
                html += '<td>' + item.RetailPrice + '</td>';
                html += '</tr>';
            });

            // Inject the rows into the TunaTable
            $('.tuna').html(html);
           

            // Add event listeners to each row in the TunaTable
            $('#TunaTable tbody tr').on('click', function () {
                stopClock();
                // Get product data from the clicked row
                var productCode = $(this).data('code');
                var productName = $(this).data('name');
                var productPrice = $(this).data('price');
                var productImage = $(this).data('image');

                // Create a new row for #myTable
                var table = $('#myTable').DataTable();
                var exists = false;
                var existingRow;

                // Check if the product already exists in #myTable
                table.rows().every(function () {
                    var data = this.data();
                    if (data[0].toLowerCase() === productName.toLowerCase()) {
                        exists = true;
                        existingRow = this;
                    }
                });

                if (exists) {
                    var $row = $(existingRow.node());
                    var quantityInput = $row.find('.quantity-input');
                    var currentQuantity = parseInt(quantityInput.val(), 10);
                    currentQuantity += 1;
                    quantityInput.val(currentQuantity);
                    updateTotal(quantityInput);
                    return;
                }

                
                var newRow = table.row.add([
                    productName,                        
                    productCode,                        
                    '<input type="number" min="1" value="1" class="quantity-input" onchange="updateTotal(this)" />',  
                    '<input type="number" min="0" max="100" step="0.01" value="0" class="discount-input" onchange="updateTotal(this)" />', 
                    productPrice,                       
                    '<input type="text" value="0" disabled class="total-amount" />',
                    '<a href="#" class="btn btn-outline-danger" onclick="Delete(this)">Delete</a>'  
                ]).draw(false);
           
                var rowNode = newRow.node();
                updateTotal($(rowNode).find('.quantity-input')); 
                updateGrandTotalRow();  
            });
            $('#myTable').on('focus', '.quantity-input, .discount-input', function () {
                this.select(); 
            });

           $('#TunaTable').DataTable({
                "ordering": false  // Disables sorting functionality on all columns
            });
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}


function CartButtonClick() {

    invoke_Product_Addition_Model();

}

function Search_Funtionality() {
    let selectedIndex = -1;
    let allProducts = [];  // This will store the product list

    // Function to fetch product suggestions based on query
    function fetchProductSuggestions(query) {
        if (allProducts.length === 0) {
            // Fetch products from the server if not already fetched
            $.ajax({
                url: '/Home/ListAll',
                method: 'GET',
                success: function (data) {
                    console.log('Data from server:', data);
                    if (Array.isArray(data)) {
                        allProducts = data;
                        filterSuggestions(query);
                    } else {
                        console.error('Unexpected data format:', data);
                        showSuggestions([]);
                    }
                },
                error: function () {
                    console.log('Error fetching product suggestions');
                }
            });
        } else {
            // Filter suggestions based on the local product list
            filterSuggestions(query);
        }
    }

    // Function to filter products based on the query
    function filterSuggestions(query) {
        const filteredProducts = allProducts.filter(product =>
            product.Name.toLowerCase().includes(query.toLowerCase())
        );

        const suggestions = filteredProducts.map(product => product.Name);
        showSuggestions(suggestions, query);
    }

    // Function to display suggestions in the autocomplete list
    function showSuggestions(suggestions, query) {
        const $list = $('#autocomplete-list');
        $list.empty();  // Clear previous suggestions

        if (suggestions.length === 0) {
            $list.hide();
            return;
        }

        selectedIndex = 0;


        suggestions.forEach((suggestion, index) => {
            const highlighted = highlightMatch(suggestion, query);

            const $item = $('<li>')
                .html(highlighted)
                .data('index', index)
                .on('click', function () {
                    const selectedProduct = $(this).text();
                    selectProduct(selectedProduct);
                    $('#productSearch').val(selectedProduct);
                    Load_Row_In_Table(selectedProduct);
                    setTimeout(function () {
                        $('#productSearch').val('');
                    }, 200);
                });

            $list.append($item);
        });

        highlightSelection();

        $list.css({
            'max-width': '300px', 
            'width': 'auto', 
            'overflow-x': 'auto' 
        });

        $list.show();
    }

    // Function to highlight matching parts of the string in the suggestion list
    function highlightMatch(text, query) {
        const regex = new RegExp('(' + query + ')', 'gi');
        return text.replace(regex, '<span class="match-highlight">$1</span>');
    }

    // Function to highlight the selected suggestion
    function highlightSelection() {
        const $list = $('#autocomplete-list');
        const $items = $list.find('li');
        $items.removeClass('selected');
        if (selectedIndex >= 0 && selectedIndex < $items.length) {
            $items.eq(selectedIndex).addClass('selected');
        }
    }

    // Function to select a product and close the suggestion list
    function selectProduct(productName) {
        $('#productSearch').val(productName);
        $('#autocomplete-list').hide();
    }

    // Event listener for input in the search field
    $('#productSearch').on('input', function () {
        const query = $(this).val().trim();
        if (query.length > 0) {
            fetchProductSuggestions(query);
        } else {
            $('#autocomplete-list').hide();
        }
    });

    // Keyboard navigation (up/down arrows, enter, escape)
    $('#productSearch').on('keydown', function (e) {
        const $list = $('#autocomplete-list');
        const $items = $list.find('li');
        const totalItems = $items.length;

        if (e.keyCode === 40) {  // Arrow Down
            if (selectedIndex < totalItems - 1) {
                selectedIndex++;
                highlightSelection();
            }
        } else if (e.keyCode === 38) {  // Arrow Up
            if (selectedIndex > 0) {
                selectedIndex--;
                highlightSelection();
            }
        } else if (e.keyCode === 13) {  // Enter Key
            if (selectedIndex >= 0 && selectedIndex < totalItems) {
                const selectedProduct = $items.eq(selectedIndex).text();
                selectProduct(selectedProduct);
                Load_Row_In_Table(selectedProduct);
                $('#productSearch').val('');
            }
        } else if (e.keyCode === 27) {  // Escape Key
            $('#autocomplete-list').hide();
        }
    });

    // Function to load a row in the table or update the quantity if the product already exists
    function Load_Row_In_Table(productName) {
        const table = $('#myTable').DataTable();
        stopClock();  // Assuming this is defined elsewhere in your code

        // Validate input
        if (productName === '') {
            alert('Product Name Cannot be Empty');
            return;
        }

        $.ajax({
            url: "/Home/ProdDetail?name=" + productName,
            type: "get",
            dataType: "json",
            success: function (result) {
                console.log(result);

                
                if (result && productName === result.Name) {
                    let exists = false;
                    let existingRow;

                    
                    table.rows().every(function () {
                        const data = this.data();
                        if (data[0].toLowerCase() === result.Name.toLowerCase()) {
                            exists = true;
                            existingRow = this;
                        }
                    });

                    if (exists) {
                        // If the product exists, update its quantity
                        const $row = $(existingRow.node());
                        const quantityInput = $row.find('.quantity-input');
                        let currentQuantity = parseInt(quantityInput.val(), 10);
                        currentQuantity += 1;
                        quantityInput.val(currentQuantity);
                        updateTotal(quantityInput);  // Assuming this function is defined elsewhere
                        return;
                    }

                    // If the product doesn't exist, add a new row to the table
                    const newRow = table.row.add([
                        result.Name,
                        result.Code,
                        '<input type="number" min="1" value="1" class="quantity-input" onchange="updateTotal(this)" />',
                        '<input type="number" min="0" max="100" step="0.01" value="0" class="discount-input" onchange="updateTotal(this)" />',
                        result.RetailPrice,
                        '<input type="text" value="0" disabled class="total-amount" />',
                        '<a href="#" class="btn btn-outline-danger" onclick="Delete(this)">Delete</a>'
                    ]).draw(false);

                    // Update the total amount for the new row
                    const rowNode = newRow.node();
                    updateTotal($(rowNode).find('.quantity-input'));
                    updateGrandTotalRow();  // Assuming this function is defined elsewhere
                } else {
                    alert('Product not found.');
                }
            },
            error: function (errormessage) {
                alert(errormessage.responseText);
            }
        });
    }

    // Close the suggestion list if the user clicks outside of the input field
    $(document).on('click', function (e) {
        if (!$(e.target).closest('#productSearch').length) {
            $('#autocomplete-list').hide();
        }
    });
}




//3rd modal function

function invoke_Sale_Updation_Modal() {
    const myModal = new bootstrap.Modal(document.getElementById('Alpha'));
    myModal.show();

    const myInput = document.getElementById('myInput');
    const buttons = document.querySelectorAll('#Alpha .modal-footer button'); // Get buttons inside modal footer
    let currentIndex = 0;  // Index of the currently focused button

    // Focus the first button when the modal opens
    myModal._element.addEventListener('shown.bs.modal', () => {
        if (myInput) {
            myInput.focus();  // Focus on the input field (if it exists)
        }
        focusButton(currentIndex);  // Focus the first button
    });

    // Function to focus a specific button based on index
    function focusButton(index) {
        buttons[index].focus();
    }

    // Event listener for keyboard navigation (Arrow keys and Enter)
    $(document).on('keydown', function (e) {
        if ($('#Alpha').hasClass('show')) {  // Ensure modal is open
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                // Move focus to the next button (right or down arrow)
                currentIndex = (currentIndex + 1) % buttons.length;
                focusButton(currentIndex);
            } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                // Move focus to the previous button (left or up arrow)
                currentIndex = (currentIndex - 1 + buttons.length) % buttons.length;
                focusButton(currentIndex);
            } else if (e.key === 'Enter') {
                // Trigger the currently focused button (Enter key)
                buttons[currentIndex].click();
            }
        }
    });
}



function UpdateSale() {

    
    var grandTotal = $('#grandTotal').text();
    var salesPersonId = $('#inputGroupSelect04').val();
    //console.log('The ID is:', salesPersonId);
    var saleDate = $('#dateTimeInput').val();
    var comments = $('#floatingTextarea').val();

    var table = $('#myTable').DataTable();

    if (table.rows().count() === 0) {
        alert('No Sales Records present in table!');
        return;
    }
    
    var tableData = [];
    table.rows().every(function () {
        var data = this.data();
        var productName = data[0];
        if (!productName || productName.trim() === "")
        {
          return;  // Skip this row and continue to the next one
        }
        console.log('Product NAmes are: ', productName);
        var productId = getProductIdDuringUpdation(productName);
        var quantityInput = $(this.node()).find('td:eq(2) input');
        var discountInput = $(this.node()).find('td:eq(3) input');

        var quantity = parseInt(quantityInput.val(), 10) || 0;
        var discount = parseFloat(discountInput.val()) || 0.0;

            tableData.push({
                ProductId: { ProductId: productId },
                RetailPrice: parseFloat(data[4]),
                Quantity: quantity,
                Discount: discount
            });

    });

    //console.log('The Entire Table Data Is:', tableData);
    console.log('JSON data is : ', JSON.stringify({
        SaleId: Global_Sale_Id,
        SalespersonID: { SalespersonID: salesPersonId },
        Total: grandTotal,
        SaleDate: saleDate,
        Comments: comments,
        SalesDetails: tableData
    }));

    $.ajax({
        url: "/Home/Update_Data",     
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            SaleId: Global_Sale_Id,
            // Pass SalespersonID as null or a valid ID
            //SalespersonID: salesPersonId || null,  // If salesPersonId is not set, send null
            SalespersonID: salesPersonId ? { SalespersonID: salesPersonId } : null,
            Total: grandTotal,
            SaleDate: saleDate,
            Comments: comments,
            SalesDetails: tableData  // Ensure that the SalesDetails data is correctly structured
        }),
        dataType: "json",
        success: function (response) {
            if (response.success) {
                Swal.fire({
                    title: 'Success!',text: 'Sale Updated successfully.',icon: 'success'});
                //table.clear().draw();
                //$('#productSearch').val('');
                //$('#inputGroupSelect04').val('').change();
                //$('#floatingTextarea').val('');
                $('.modal').modal('hide');
                populate_Records_table_again();
                Global_Sale_Id = 0;
            } else {
                alert('Failed to Update data: ' + response.message);
            }
        },
        error: function (errormessage) {
            console.error('Error:', errormessage);
            alert('An error occurred: ' + errormessage.responseText);
        }
    });

}

function getProductIdDuringUpdation(productName) {
    if (!productName) {
        alert('Product name cannot be empty');
        return null;  
    }

    var productId = null;

    $.ajax({
        url: "/Home/GetProductID?name=" + encodeURIComponent(productName),
        type: "GET",
        contentType: "application/json",
        dataType: "json",
        async: false, 
        success: function (response) {
            productId = response; 
        },
        error: function (errormessage) {
            alert(errormessage.responseText); 
        }
    });

    return productId;  
}

function DeleteSale() {

    
    console.log('i have got his sale id: ', Global_Sale_Id);
    $.ajax({
        url: '/Home/Delete_Sale_During_Editing?saleid=' + encodeURIComponent(Global_Sale_Id),
        type: "post",
        dataType: "json",
        success: function (result) {

            //alert('Sale Deleted!'); 
            Swal.fire({
                title: 'Success!', text: 'Sale Deleted', icon: 'Success'
            });
            var table = $('#myTable').DataTable();
            table.clear().draw();
            $('#productSearch').val('');
            $('#inputGroupSelect04').val('').change();
            $('#floatingTextarea').val('');
            window.location.replace("/Home/Point_Of_Sale");
            
        },
        error: function (errormessage) {

            alert(errormessage.responseText);
        }
    });
}

function populate_Records_table_again() {
    var table = $('#recordsTable').DataTable(); 
    var currentPage = table.page();  
    var pageSize = table.page.len(); 

    $.ajax({
        url: '/Home/Load_Records',
        type: "get",
        dataType: "json",
        success: function (result) {
            console.log('Data retrieved:', result);

            // Sort the records by SaleId in descending order
            result.sort(function (a, b) {
                return b.SaleId - a.SaleId;  // Sorting by SaleId in descending order
            });

            var html = '';
            $.each(result, function (key, item) {
                var saleDate = new Date(parseInt(item.SaleDate.replace('/Date(', '').replace(')/', '')));
                var formattedDate = saleDate.toLocaleDateString();

                html += '<tr>';
                html += '<td style="display:none;">' + item.SaleId + '</td>';  // Hidden SaleId column
                html += '<td>' + formattedDate + '</td>';
                html += '<td>' + item.Total + '</td>';
                html += '<td>' + item.SalespersonID.Name + '</td>';
                html += '<td>' + item.Comments + '</td>';
                html += '<td><button class="btn btn-outline-danger" onclick="DeleteCompleteSale(' + item.SaleId + ')">Delete</button></td>';
                html += '</tr>';
            });
            
            table.clear();          
            table.rows.add($(html));            
            table.draw();           
            table.page(currentPage).draw('page');       
        },
        error: function (errormessage) {
            alert('Error loading records: ' + errormessage.responseText);
        }
    });
}

function ClearAll() {
    var table = $('#myTable').DataTable();
    table.clear().draw();
    $('.dataTables_empty').hide();
    $('#inputGroupSelect04').val(null);
    $('#floatingTextarea').val('');
    startClock();
}