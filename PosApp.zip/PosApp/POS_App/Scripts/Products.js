﻿
var Global_Table_Instance = null;
$(document).ready(function () {

    $('#navbar-toggle').on('click', function () {
        $('.navbar-menu').toggleClass('active');
    });

    Global_Table_Instance = $('#myTable').DataTable();
    LoadData();
    

    $('#myModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); 
        var operation = button.data('operation'); 

        if (operation === 'add') {
            emptyAllFields();
            $('#btnAdd').show();     
            $('#btnUpdate').hide();  
                  
        } else if (operation === 'update') {
            $('#myModalLabel').text('Update This Product?');
            $('#btnAdd').hide();    
            $('#btnUpdate').show();  
            
        }
    });


    $('#myModal').on('hide.bs.modal', function () {
        $('#btnAdd').show();     
        $('#btnUpdate').hide();  
        emptyAllFields();       
    });

});

//function LoadData() {
//    $.ajax( {
//        url: "/Home/ListAll",
//        type: "GET",
//        dataType: "json",
  
//        success: function (result) {
//            console.log(result);
//            var html = '';
//            $.each(result, function (key, item) {
                
//                var creationDate = new Date(parseInt(item.CreationDate.substr(6)));
//                var formattedDate = creationDate.toLocaleDateString();
//                html += '<tr>';
//                html += '<td>' + item.ProductId + '</td>';
//                html += '<td>' + item.Name + '</td>';
//                html += '<td>' + item.Code + '</td>';
//                html += '<td><img style="max-width:100px;" src="' + item.ImageURL + '" alt="Product Image"></td>';
//                html += '<td >' + item.CostPrice + '</td>';
//                html += '<td >' + item.RetailPrice + '</td>';
//                html += '<td >' + formattedDate + '</td>';
//                html += '<td><a href="#" class="btn btn-outline-warning" onclick="return getbyID(' + item.ProductId + ')">Edit</a> | <a href="#" class="btn btn-outline-danger" onclick="Delete(' + item.ProductId  + ')">Delete</a></td>';
//                html += '</tr>';
//            });
//            //$('.tbody').html(html);
//            //Global_Table_Instance = $('#myTable').DataTable();

//            // Clear existing table and add new rows
//            Global_Table_Instance.clear().draw();
//            Global_Table_Instance.rows.add($(html)).draw();
           
//        },
//        error: function (errormessage) {
//            alert(errormessage.responseText);
//        }
//    });
// }

function LoadData() {
    var currentPage = Global_Table_Instance.page();  // Get the current page before reloading the data

    $.ajax({
        url: "/Home/ListAll",
        type: "GET",
        dataType: "json",
        success: function (result) {
            console.log(result);

            // Save the current data before adding the new data to prevent pagination reset
            var currentData = Global_Table_Instance.rows().data().toArray();

            // Now clear and add new rows to the DataTable (but don't reset pagination)
            Global_Table_Instance.clear();

            // Loop through the response and add rows
            $.each(result, function (key, item) {
                var creationDate = new Date(parseInt(item.CreationDate.substr(6)));
                var formattedDate = creationDate.toLocaleDateString();

                var rowData = [
                    item.ProductId,
                    item.Name,
                    item.Code,
                    '<img style="max-width:100px;" src="' + item.ImageURL + '" alt="Product Image">',
                    item.CostPrice,
                    item.RetailPrice,
                    formattedDate,
                    '<a href="#" class="btn btn-outline-warning" onclick="return getbyID(' + item.ProductId + ')">Edit</a> | <a href="#" class="btn btn-outline-danger" onclick="Delete(' + item.ProductId + ')">Delete</a>'
                ];

                Global_Table_Instance.row.add(rowData);
            });

            // Draw the table without changing the current page
            Global_Table_Instance.draw(false);

            // Restore the previous page after adding the data
            Global_Table_Instance.page(currentPage).draw('page');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}





function getbyID(pID) {
    $('#ProductId').css('border-color', 'lightgrey');
    $('#Name').css('border-color', 'lightgrey');
    $('#Code').css('border-color', 'lightgrey');
    $('#ImageURL').css('border-color', 'lightgrey');
    $('#CostPrice').css('border-color', 'lightgrey');
    $('#RetailPrice').css('border-color', 'lightgrey');
    $.ajax({
        url: "/Home/getbyID/" + pID,
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (result) {
            console.log(result);
            ExistingCode = result.Code;
            $('#ProductId').val(result.ProductId);
            $('#Name').val(result.Name);
            $('#Code').val(result.Code);
            $('#ImageURL').val(result.ImageURL);
            $('#CostPrice').val(result.CostPrice);
            $('#RetailPrice').val(result.RetailPrice);
            $('#myModal').modal('show');
            $('#btnUpdate').show();
            $('#btnAdd').hide();
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}


function validate() {
    var Name = $('#Name').val().trim();
    var Code = $('#Code').val().trim();
    var ImageURL = $('#ImageURL').val().trim();
    var CostPrice = $('#CostPrice').val().trim();
    var RetailPrice = $('#RetailPrice').val().trim();


    // Check for empty fields

    if (!Name) {
       // alert("Name is required!");
        return false;
    }

    if (!Code) {
       // alert("code is required!");
        return false;     
    }
    
    //if (!ImageURL) {
    //    alert("Image-URL is required!");
    //    return false;
    //}
    if (!CostPrice) {
       // alert("Cost Price is required!");
        return false;
    }
    if (!RetailPrice) {
       // alert("Retail Price is required!");

        return false;
        
    }
    // Check if it is a valid code
    if (Code.length > 6) {
        alert("Code length should be not be greater then 6 characters.");
        return false;
    }

     if (isNaN(CostPrice) || isNaN(RetailPrice)) {
        alert("Please enter valid numeric values for prices.");
        return false;
    }

     if (CostPrice <= 0 || RetailPrice <= 0) {
        alert("Cost Price and Retail Price cannot be zero or less");
        return false;
    }

     if (CostPrice > 99999999.99 || CostPrice > 99999999.99) {
        alert("Cost Price and Retail Price cannot exceed 99,999,999.99");
        return false;
    }

    return true; // All validations passed
}

var ExistingCode = $('#Code').val();
function codeVerifierforAdd(val) {
    var isUnique = true; // Flag for uniqueness
    $.ajax({
        url: "/Home/ListAll",
        type: "GET",
        dataType: "json",
        async: false, 
        success: function (result) {
            $.each(result, function (key, item) {
                if (item.Code === val) {
                    alert('Code Must Be Unique');
                    isUnique = false; 
                    return;
                }
            });
        },
        error: function (error) {
            alert(error.responseText); // Handle AJAX error
            isUnique = false; // Mark as not unique if there's an error
        }
    });
    return isUnique; // Return the uniqueness flag
}

function Add() {
    
    var answer = validate();
    if (answer == false) {

        Swal.fire({
            title: 'Error!', text: 'Entry Failed.', icon: 'Error'
        });


        return;
    }
    var newCode = $('#Code').val().trim();
    var isCodeUnique = true; // Assume it's unique by default

    // Check if the code has changed
    if (newCode !== ExistingCode) {
        isCodeUnique = codeVerifierforAdd(newCode);
        if (!isCodeUnique) {

            Swal.fire({
                title: 'Error!', text: 'Insertion aborted due to duplicate code.', icon: 'Error'
            });

            return false; // Exit if the code is not unique
        }
    }
  
        var Name = $('#Name').val().trim();
        var Code = $('#Code').val().trim();
        var ImageURL = $('#ImageURL').val().trim();
        var CostPrice = $('#CostPrice').val().trim();
        var RetailPrice = $('#RetailPrice').val().trim();
        const obj = {
        Name: Name,
        Code: Code,
        ImageURL: ImageURL,
        CostPrice: CostPrice,
        RetailPrice: RetailPrice
    };
    $.ajax({
        url: '/Home/AddProd',
        type:'post',
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(obj),
        success: function (result) {

            Swal.fire({
                title: 'Success!', text: 'Entry Successfull !', icon: 'Success'
            });

            emptyAllFields();
            
            // Hide the modal
            $('#myModal').modal('hide');

            LoadData();

        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }

    });
    
}

//function Add() {
//    var answer = validate();
//    if (answer == false) {
//        Swal.fire({
//            title: 'Error!',
//            text: 'Entry Failed.',
//            icon: 'error'
//        });
//        return;
//    }

//    var newCode = $('#Code').val().trim();
//    var isCodeUnique = true;

//    // Check for uniqueness of code (only if it has changed)
//    if (newCode !== ExistingCode) {
//        isCodeUnique = codeVerifierforAdd(newCode);
//        if (!isCodeUnique) {
//            Swal.fire({
//                title: 'Error!',
//                text: 'Insertion aborted due to duplicate code.',
//                icon: 'error'
//            });
//            return false;
//        }
//    }

//    // Prepare the form values for the new product
//    var Name = $('#Name').val().trim();
//    var Code = $('#Code').val().trim();
//    var ImageURL = $('#ImageURL').val().trim() || 'default-image.jpg';  // Set default if empty
//    var CostPrice = parseFloat($('#CostPrice').val().trim());
//    var RetailPrice = parseFloat($('#RetailPrice').val().trim());

//    // Validate if cost and retail prices are valid
//    if (isNaN(CostPrice) || isNaN(RetailPrice)) {
//        Swal.fire({
//            title: 'Error!',
//            text: 'Please enter valid numeric values for prices.',
//            icon: 'error'
//        });
//        return;
//    }

//    // Create object for the new product
//    const obj = {
//        Name: Name,
//        Code: Code,
//        ImageURL: ImageURL,
//        CostPrice: CostPrice,
//        RetailPrice: RetailPrice
//    };

//    // Send the data to the server
//    $.ajax({
//        url: '/Home/AddProd',
//        type: 'POST',
//        dataType: 'json',
//        contentType: 'application/json',
//        data: JSON.stringify(obj),
//        success: function (result) {
//            // Success response
//            Swal.fire({
//                title: 'Success!',
//                text: 'Entry Successful!',
//                icon: 'success'
//            });

//            // Empty fields and close modal
//            emptyAllFields();
//            $('#myModal').modal('hide');

//            // Prepare data for new row
//            var productid = result.ProductId;
//            var creationdate = result.CreationDate;
//            var formattedCreationDate = new Date(creationdate).toLocaleDateString();

//            var newRowData = [
//                productid,
//                Name,
//                Code,
//                '<img style="max-width:100px;" src="' + ImageURL + '" alt="Product Image">',
//                CostPrice.toFixed(2),
//                RetailPrice.toFixed(2),
//                formattedCreationDate,
//                '<a href="#" class="btn btn-outline-warning" onclick="return getbyID(' + productid + ')">Edit</a> | <a href="#" class="btn btn-outline-danger" onclick="Delete(' + productid + ')">Delete</a>'
//            ];

//            // Add the new row to the DataTable without resetting pagination
//            Global_Table_Instance.row.add(newRowData).draw(false); // `draw(false)` preserves pagination
//        },
//        error: function (errormessage) {
//            alert(errormessage.responseText);
//        }
//    });
//}







function codeVerifier(val) {
    var isUnique = true; 
    $.ajax({
        url: "/Home/ListAll",
        type: "GET",
        dataType: "json",
        async: false, 
        success: function (result) {
            $.each(result, function (key, item) {
                if (item.Code === val) {
                    alert('Code Must Be Unique');
                    isUnique = false; 
                    return; 
                }
            });
        },
        error: function (error) {
            alert(error.responseText); 
            isUnique = false; 
        }
    });
    return isUnique; 
}

function Update() {

    var answer = validate();
    if (answer == false) {


        Swal.fire({
            title: 'Error!', text: 'Failed To Update', icon: 'Error'
        });

        return;

    }
    var newCode = $('#Code').val().trim();
    var isCodeUnique = true;

 
    if (newCode !== ExistingCode) {
        isCodeUnique = codeVerifier(newCode);
        if (!isCodeUnique) {

            Swal.fire({
                title: 'Error!', text: 'Update aborted due to duplicate code.', icon: 'Error'
            });

            return false;
        }
    }

    
        var ProductId = $('#ProductId').val().trim();
        var Name = $('#Name').val().trim();
        var Code = $('#Code').val().trim();
        var ImageURL = $('#ImageURL').val().trim();
        var CostPrice = $('#CostPrice').val().trim();
        var RetailPrice = $('#RetailPrice').val().trim();
        const obj = {
            ProductId: ProductId,
            Name: Name,
            Code: Code,
            ImageURL: ImageURL,
            CostPrice: CostPrice,
            RetailPrice: RetailPrice
        };
        $.ajax({
            url: '/Home/UpdateProd',
            type: 'post',
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify(obj),
            success: function () {

                Swal.fire({
                    title: 'Success!', text: 'Updation Successfull !', icon: 'Success'
                });

                emptyAllFields();
                LoadData(); 
                $('#myModal').modal('hide');

            },
            error: function (errormessage) {
                alert("Failed ");
            }
        });
    
}
    
   

//function Delete(id) {
//    $.ajax({
//        url: '/Home/DeleteProd?id=' + id,
//        type: 'post',
//        dataType: 'json',
//        contentType: 'application/json',

//        success: function (result) {
//            if (result.status === 1) {
//                // If status is 1, the product was successfully deleted
//                var table = $('#myTable').DataTable();
//                // Find the row with the matching ID and remove it from the table
//                table.rows().every(function () {
//                    var data = this.data();
//                    if (data[0] === id) { // Assuming ProductId is in the first column
//                        this.remove(); // Remove the row from the DataTable
//                    }
//                });

                
//                LoadData();

//                Swal.fire({
//                    title: 'Success!', text: result.message, icon: 'Success' // "Product deleted successfully!"
//                });
                
//            }
//            else if (result.status === 0) {
//                Swal.fire({
//                    title: 'Error!', text: result.message, icon: 'Error' // "Product Already in use"
//                });


//            }
//            else {

//                Swal.fire({
//                    title: 'Error!', text: result.message, icon: 'Error' // "An error occurred while trying to delete the product."
//                });
    
//            }
//        },
//        error: function (error) {
//            alert("Deletion Failed");
//        }
//    });
//}

function Delete(id) {
    // Prevent default link behavior (page jump to top)
    event.preventDefault();

    $.ajax({
        url: '/Home/DeleteProd?id=' + id,
        type: 'post',
        dataType: 'json',
        contentType: 'application/json',

        success: function (result) {
            if (result.status === 1) {
                // If status is 1, the product was successfully deleted
                // Find the row with the matching ID and remove it from the DataTable
                Global_Table_Instance.rows().every(function () {
                    var data = this.data();
                    if (data[0] === id) { // Assuming ProductId is in the first column
                        this.remove(); // Remove the row from the DataTable
                    }
                });

                // Draw the table again to reflect the changes without reloading the entire table
                Global_Table_Instance.draw(false);

                Swal.fire({
                    title: 'Success!',
                    text: result.message,
                    icon: 'success' // Product deleted successfully
                });

            } else if (result.status === 0) {
                Swal.fire({
                    title: 'Error!',
                    text: result.message,
                    icon: 'error' // Product already in use or some other error
                });

            } else {
                Swal.fire({
                    title: 'Error!',
                    text: result.message,
                    icon: 'error' // General error
                });
            }
        },
        error: function (error) {
            Swal.fire({
                title: 'Error!',
                text: 'Deletion Failed',
                icon: 'error'
            });
        }
    });
}


function emptyAllFields() {
    $('#ProductId').val('');
    $('#Name').val('');
    $('#Code').val('');
    $('#ImageURL').val('');
    $('#CostPrice').val('');
    $('#RetailPrice').val('');
}