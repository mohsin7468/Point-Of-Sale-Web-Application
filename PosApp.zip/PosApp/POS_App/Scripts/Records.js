﻿////$(document).ready(function () {
  
////    populate_table();
    
////});

////function populate_table() {

////    $.ajax({
////        url: '/Home/Load_Records',
////        type: "get",
////        dataType: "json",
////        success: function (result) {
////            console.log('hi', result);
////            // Sort the records by SaleId in descending order
////            result.sort(function (a, b) {
////                return b.SaleId - a.SaleId;  // Sorting by SaleId in descending order
////            });
////            var html = '';
////            $.each(result, function (key, item) {
////                var saleDate = new Date(parseInt(item.SaleDate.replace('/Date(', '').replace(')/', '')));
////                var formattedDate = saleDate.toLocaleDateString();
////                html += '<tr>';
////                html += '<td style="Display:none;">' + item.SaleId + '</td>';
////                html += '<td>' + formattedDate + '</td>';
////                html += '<td>' + item.Total + '</td>';
////                html += '<td>' + item.SalespersonID.Name + '</td>';
////                html += '<td>' + item.Comments + '</td>';
////                //html += '<td>' + '-' + '</td>';
////                html += '<td><button class="btn btn-outline-danger" onclick="Delete(' + item.SaleId + ')">Delete</button></td>';
////                html += '</tr>';
////            });

////            $('.tbody').html(html);
////            var table = $('#myTable').DataTable({
////                "order": [[0, 'desc']],  // Sort by the first column (SaleId) in descending order
////                "paging": true,  // Enable pagination if needed
////                "searching": true,  // Enable search if needed
////                "info": true  // Enable info text if needed
////            });

////            $('#myTable tbody').on('click', 'tr', function () {

////                if ($(event.target).hasClass('btn btn-outline-danger')) {
                   
////                    return;  
////                }

////                var rowData = table.row(this).data();
                
////               // console.log('You clicked:', rowData);  

////                var saleid = rowData[0];

////                $.ajax({
////                    url: '/Home/Fill_The_Relevant_Data?saleid=' + encodeURIComponent(saleid),
////                    type: "post",
////                    dataType: "json",            
////                    success: function (result) {
                        
////                        console.log('hi data retrieved successfully', result);                       
////                        localStorage.setItem('saleDetails', JSON.stringify(result));
////                        window.location.replace("/Home/GivePOSViewForEditing");

////                    },
////                    error: function (errormessage) {

////                        alert(errormessage.responseText);
////                    }
////                });
                
////            });
////        },
////        error: function (errormessage) {
            
////            alert(errormessage.responseText);
////        }
////    });
////}

////function Delete(saleid) {
    
////    console.log('i have got his sale id: ',saleid);
////    $.ajax({
////        url: '/Home/Delete_Sale?saleid=' + encodeURIComponent(saleid),
////        type: "post",
////        dataType: "json",
////        success: function (result) {
////            //alert('Sale Deleted!');        
////            var table = $('#myTable').DataTable();
////            var currentPage = table.page();
////            table.rows().every(function () {
////                var row = this.node();
////                var rowData = table.row(row).data();
////                if (rowData && rowData[0] == saleid) { 
////                    table.row(row).remove().draw(false); 
////                }
////            });
////        },
////        error: function (errormessage) {

////            alert(errormessage.responseText);
////        }
////    });
////}

$(document).ready(function () {
    populate_table();
});

function populate_table() {
    $.ajax({
        url: '/Home/Load_Records',
        type: "get",
        dataType: "json",
        success: function (result) {
            console.log('hi', result);
            
            result.sort(function (a, b) {
                return b.SaleId - a.SaleId;  
            });

            var html = '';
            $.each(result, function (key, item) {
                var saleDate = new Date(parseInt(item.SaleDate.replace('/Date(', '').replace(')/', '')));
                var formattedDate = saleDate.toLocaleDateString();

                html += '<tr>';
                html += '<td style="display:none;">' + item.SaleId + '</td>';  
                html += '<td>' + formattedDate + '</td>';
                html += '<td>' + item.Total + '</td>';
                html += '<td>' + item.SalespersonID.Name + '</td>';
                html += '<td>' + item.Comments + '</td>';
                html += '<td><button class="btn btn-outline-danger" onclick="DeleteCompleteSale(' + item.SaleId + ')">Delete</button></td>';
                html += '</tr>';
            });

            
            $('.records_tbody').html(html);

            
            $('#recordsTable').DataTable({
                "order": [[0, 'desc']],  
                "paging": true,  
                "searching": true, 
                "info": true  
            });

            
            $('#recordsTable tbody').on('click', 'tr', function (event) {
                if ($(event.target).hasClass('btn btn-outline-danger')) {
                    // If the delete button was clicked, do nothing
                    return;
                }

                var rowData = $('#recordsTable').DataTable().row(this).data();
                var saleid = rowData[0]; 

                
                $.ajax({
                    url: '/Home/Fill_The_Relevant_Data?saleid=' + encodeURIComponent(saleid),
                    type: "post",
                    dataType: "json",
                    success: function (result) {
                        console.log('Data retrieved successfully:', result);
                        localStorage.setItem('saleDetails', JSON.stringify(result));
                        window.location.replace("/Home/GivePOSViewForEditing");
                    },
                    error: function (errormessage) {
                        alert(errormessage.responseText);
                    }
                });
            });
        },
        error: function (errormessage) {
            alert('Error loading records: ' + errormessage.responseText);
        }
    });
}

function DeleteCompleteSale(saleid) {
    console.log('Sale ID to delete: ', saleid);
    $.ajax({
        url: '/Home/Delete_Sale?saleid=' + encodeURIComponent(saleid),
        type: "post",
        dataType: "json",
        success: function (result) {
            var table = $('#recordsTable').DataTable();
            var currentPage = table.page();

            // Remove the deleted sale from the table
            table.rows().every(function () {
                var row = this.node();
                var rowData = table.row(row).data();
                if (rowData && rowData[0] == saleid) {
                    table.row(row).remove().draw(false);
                }
            });

            
        },
        error: function (errormessage) {
            alert('Error deleting sale: ' + errormessage.responseText);
        }
    });
}
