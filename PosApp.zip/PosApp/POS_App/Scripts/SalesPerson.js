﻿var Global_Instance = null;

$(document).ready(function () {

    $('#navbar-toggle').on('click', function () {
        $('.navbar-menu').toggleClass('active');
    });

    

    LoadData();

    $('#myModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Button that triggered the modal
        var operation = button.data('operation'); // Extract operation from data attributes

        if (operation === 'add') {
            emptyAllFields();
            $('#btnAdd').show();
            $('#btnUpdate').hide();

        } else if (operation === 'update') {
            $('#myModalLabel').text('Update This Product?');
            $('#btnAdd').hide();
            $('#btnUpdate').show();

        }
    });

    // Optionally, you can add an event to hide the modal and reset the state on hide
    $('#myModal').on('hide.bs.modal', function () {
        $('#btnAdd').show();     // Reset the Add button visibility
        $('#btnUpdate').hide();  // Reset the Update button visibility
        emptyAllFields();        // Clear the fields when modal is hidden
    });

});

//function LoadData() {
//    $.ajax({
//        url: "/Home/ListAllSalesPersons",
//        type: "GET",
//        dataType: "json",

//        success: function (result) {
//            console.log(result);
//            var html = '';
//            $.each(result, function (key, item) {
//                //Converting Creation Date
//                var creationDate = new Date(parseInt(item.EnteredDate.substr(6)));
//                var formattedDate = creationDate.toLocaleDateString();
//                html += '<tr>';
//                html += '<td>' + item.SalespersonID + '</td>';
//                html += '<td>' + item.Name + '</td>';
//                html += '<td>' + item.Code + '</td>';
//                html += '<td >' + formattedDate + '</td>';
//                html += '<td><a href="#" class="btn btn-outline-warning" onclick="return  getbyID(' + item.SalespersonID + ')">Edit</a> | <a href="#" class="btn btn-outline-danger" onclick="Delete(' + item.SalespersonID+ ')">Delete</a></td>';
//                html += '</tr>';
//            });
//            $('.tbody').html(html);
//            Global_Instance = $('#myTable').DataTable();
            
//        },
//        error: function (errormessage) {
//            alert(errormessage.responseText);
//        }
//    });
//}

function LoadData() {
    $.ajax({
        url: "/Home/ListAllSalesPersons",
        type: "GET",
        dataType: "json",

        success: function (result) {
            console.log(result);
            var html = '';
            $.each(result, function (key, item) {
                //Converting Creation Date
                var creationDate = new Date(parseInt(item.EnteredDate.substr(6)));
                var formattedDate = creationDate.toLocaleDateString();
                html += '<tr>';
                html += '<td>' + item.SalespersonID + '</td>';
                html += '<td>' + item.Name + '</td>';
                html += '<td>' + item.Code + '</td>';
                html += '<td>' + formattedDate + '</td>';
                html += '<td><a href="#" class="btn btn-outline-warning" onclick="return getbyID(' + item.SalespersonID + ')">Edit</a> | <a href="#" class="btn btn-outline-danger" onclick="Delete(' + item.SalespersonID + ', event)">Delete</a></td>';
                html += '</tr>';
            });
            // Add the rows to the table body
            $('.tbody').html(html);

            // Only initialize the DataTable once when the page loads
            if (!Global_Instance) {
                Global_Instance = $('#myTable').DataTable();
            } else {
                // Redraw the DataTable without resetting its state (pagination, sorting, etc.)
                Global_Instance.clear().rows.add($(html)).draw(false);
            }
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}




function getbyID(id) {
    $('#SalespersonID').css('border-color', 'lightgrey');
    $('#Name').css('border-color', 'lightgrey');
    $('#Code').css('border-color', 'lightgrey');
    $.ajax({
        url: "/Home/getSalesPersonbyID/" + id,
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (result) {
            console.log(result);
            ExistingCode = result.Code;
            $('#SalespersonID').val(result.SalespersonID);
            $('#Name').val(result.Name);
            $('#Code').val(result.Code);
            $('#myModal').modal('show');
            $('#btnUpdate').show();
            $('#btnAdd').hide();
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}


function validate() {
    var Name = $('#Name').val().trim();
    var Code = $('#Code').val().trim();

    

    if (!Name) {
        //alert("Name is required!");
        return false;
    }

    if (!Code) {
        //alert("code is required!");
        return false;
    }


    if (Code.length > 6) {
        alert("Code length should be not be greater then 6 characters.");
        return false;
    }

    return true; 
}

var ExistingCode = $('#Code').val();
function codeVerifierforAdd(val) {
    var isUnique = true; // Flag for uniqueness
    $.ajax({
        url: "/Home/ListAllSalesPersons",
        type: "GET",
        dataType: "json",
        async: false, 
        success: function (result) {
            $.each(result, function (key, item) {
                if (item.Code === val) {
                    alert('Code Must Be Unique');
                    isUnique = false; // Set unique flag to false
                    return; 
                }
            });
        },
        error: function (error) {
            alert(error.responseText); 
            isUnique = false; 
        }
    });
    return isUnique; // Return the uniqueness flag
}



function Add() {
    var answer = validate();
    if (answer == false) {
        Swal.fire({
            title: 'Error!', text: 'Entry Failed!', icon: 'Error'
        });
        return;
    }

    var newCode = $('#Code').val().trim();
    var isCodeUnique = true;

  
    if (newCode !== ExistingCode) {
        isCodeUnique = codeVerifierforAdd(newCode);
        if (!isCodeUnique) {
            Swal.fire({
                title: 'Error!', text: 'Insertion aborted due to duplicate code.', icon: 'Error'
            });
            return false; 
        }
    }

    var Name = $('#Name').val().trim();
    var Code = $('#Code').val().trim();
    const obj = {
        Name: Name,
        Code: Code,
    };

    $.ajax({
        url: '/Home/AddSalesPer',
        type: 'post',
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(obj),
        success: function (response) {
            
            var fetchedSalespersonID = response.SalespersonID; // This is the ID returned from the server

            Swal.fire({
                title: 'Success!', text: 'Entry Successful!', icon: 'Success'
            });

            
            var newRow = '<tr>';
            newRow += '<td>' + fetchedSalespersonID + '</td>'; 
            newRow += '<td>' + obj.Name + '</td>';
            newRow += '<td>' + obj.Code + '</td>';
            newRow += '<td>' + new Date().toLocaleDateString() + '</td>'; 
            newRow += '<td><a href="#" class="btn btn-outline-warning" onclick="return getbyID(' + fetchedSalespersonID + ')">Edit</a> | <a href="#" class="btn btn-outline-danger" onclick="Delete(' + fetchedSalespersonID + ')">Delete</a></td>';
            newRow += '</tr>';

            
            Global_Instance.row.add($(newRow)).draw(false); 

            emptyAllFields();
            $('#myModal').modal('hide');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}



function codeVerifier(val) {
    var isUnique = true; // Flag for uniqueness
    $.ajax({
        url: "/Home/ListAllSalesPersons",
        type: "GET",
        dataType: "json",
        async: false, 
        success: function (result) {
            $.each(result, function (key, item) {
                if (item.Code === val) {
                    alert('Code Must Be Unique');
                    isUnique = false; // Set unique flag to false
                    return; 
                }
            });
        },
        error: function (error) {
            alert(error.responseText);
            isUnique = false; // Mark as not unique if there's an error
        }
    });
    return isUnique; // Return the uniqueness flag
}

function Update() {

    var answer = validate();
    if (answer == false) {

        Swal.fire({
            title: 'Error!', text: 'Failed To Update', icon: 'Error'
        });

        return;

    }
    var newCode = $('#Code').val().trim();
    var isCodeUnique = true; // Assume it's unique by default

    // Check if the code has changed
    if (newCode !== ExistingCode) {
        isCodeUnique = codeVerifier(newCode);
        if (!isCodeUnique) {

            Swal.fire({
                title: 'Error!', text: 'Update aborted due to duplicate code.', icon: 'Error'
            });

            return false; // Exit if the code is not unique
        }
    }


    var SalespersonID = $('#SalespersonID').val().trim();
    var Name = $('#Name').val().trim();
    var Code = $('#Code').val().trim();

    const obj = {
        SalespersonID: SalespersonID,
        Name: Name,
        Code: Code
    };
    $.ajax({
        url: '/Home/UpdateSalesPer',
        type: 'post',
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(obj),
        success: function () {

            Swal.fire({
                title: 'Success!', text: 'Updation Successfull', icon: 'Success'
            });

            emptyAllFields();
            LoadData(); // Reload data to refresh the table or list
            $('#myModal').modal('hide');

        },
        error: function (errormessage) {
            alert("Failed");
        }
    });

}





function Delete(id, event) {
    event.preventDefault();  // Prevent the default behavior (which would be scrolling the page)


        $.ajax({
            url: '/Home/DeleteSalesPer/' + id,
            type: 'post',
            dataType: 'json',
            contentType: 'application/json',

            success: function (result) {

                Swal.fire({
                    title: 'Success!', text: 'Record Deleted !', icon: 'Success'
                });
      
                LoadData();

            },
            error: function (error) {
                alert("Deletion Failed");
            }
        });

}







function emptyAllFields() {
    $('#SalespersonID').val('');
    $('#Name').val('');
    $('#Code').val('');

}